import React from 'react';
import './style.css';
import Header from './Components/Header';
import Home from './Components/Home';
import Login from './Components/Login';
import { BrowserRouter, Routes,  Route } from 'react-router-dom';

export default function App() {
  return (
    
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Header
        />}>
          <Route index element={<Home />} />
          <Route path="login" element={<Login
          />} />
        
        </Route>
      </Routes>
    </BrowserRouter>
  
  );
}
