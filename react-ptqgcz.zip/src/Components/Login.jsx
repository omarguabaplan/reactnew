import React from 'react';
import styled from 'styled-components';
import firebase from 'firebase/compat/app';
import * as firebaseui from 'firebaseui';
import 'firebaseui/dist/firebaseui.css';

export default function Login () {
  return (
    <div>
      Login
    </div>
  );
}
